#' Remplacement des NA par la moyenne
#' @param x a vector
#' @return a vector
#' @export
#' @importFrom base
#' @examples
replace_na = function(x) {
  x1 = which(is.na(x))
  x[x1]= mean(x,na.rm=TRUE)
  return (x)
}


