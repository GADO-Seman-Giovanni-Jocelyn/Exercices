# Importation des bases

library(haven)
data1 = read_dta("C:/Users/ASUS/Desktop/ISEP 2/Traitements statististiques avec R/Projet_GADO&MOUSSA/Projet_GADO&MOUSSA/cout_intrants_apure.dta")
data2 = read_dta("C:/Users/ASUS/Desktop/ISEP 2/Traitements statististiques avec R/Projet_GADO&MOUSSA/Projet_GADO&MOUSSA/selection.dta")
data3 = read_dta("C:/Users/ASUS/Desktop/ISEP 2/Traitements statististiques avec R/Projet_GADO&MOUSSA/Projet_GADO&MOUSSA/menages_revenu_positif.dta")
data4 = read_dta("C:/Users/ASUS/Desktop/ISEP 2/Traitements statististiques avec R/Projet_GADO&MOUSSA/Projet_GADO&MOUSSA/cultures_et_qte_recolte.dta")
data5 = read_dta("C:/Users/ASUS/Desktop/ISEP 2/Traitements statististiques avec R/Projet_GADO&MOUSSA/Projet_GADO&MOUSSA/culture_prix.dta")

data1 = zap_labels(data1)
data2 = zap_labels(data2)
data3 = zap_labels(data3)
data4 = zap_labels(data4)
data5 = zap_labels(data5)

list_couts = names(data1[2])
list_revenus = names(data3[5])

# Création de l'application
library (shiny)
library(shinydashboard)
library(DT)
library(dplyr)
library(ggplot2)

ui = dashboardPage(skin = 'green',
  dashboardHeader(
    title = tags$h1("EHCVM_REVENU AGRICOLE", style= "font-size : 13px; color: white; font-weight: bold;")),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Données",tabName = "Données",icon = icon ("table"),
        menuSubItem("Coûts_intrants",tabName= "coûts_intrants",icon = icon("chart-bar")),
        menuSubItem("Revenus_agricoles",tabName= "revenus_agricoles",icon = icon("chart-bar")),
        menuSubItem("Revenus_positifs",tabName= "revenus_positifs",icon = icon("chart-bar")),
        menuSubItem("Cultures et quantitées recoltées",tabName= "cultures_et_quantitées_recoltées",icon = icon("chart-bar")),
        menuSubItem("Cultures et prix",tabName= "cultures_et_prix",icon = icon("chart-bar"))),
      menuItem("Analyse",tabName = "analyse",icon = icon ("chart-pie"),
        menuSubItem("Analyse univariée",tabName= "analyse_uni",icon = icon("chart-area")),
        menuSubItem("Analyse bivariée",tabName= "analyse_biv",icon = icon("chart-area")))
    )



  ),
    dashboardBody(
      tabItems(
        tabItem("coûts_intrants",dataTableOutput("couts_in")),
        tabItem("revenus_agricoles",dataTableOutput("rev_agri")),
        tabItem("revenus_positifs",dataTableOutput("rev_posi")),
        tabItem("cultures_et_quantitées_recoltées",dataTableOutput("cul_qt_recol")),
        tabItem("cultures_et_prix",dataTableOutput("cult_prix")),
        tabItem("analyse_uni",selectInput("select1","Bases disponibles",choices = c("Bases_coûts","Bases_ménages_rev_pos"),verbatimTextOutput("select1_out")),
                selectInput("select2","Variables disponibles",choices = NULL),
                verbatimTextOutput("select2_out"),
        actionButton("Bouton1","Valider"),verbatimTextOutput("Bouton1_out")),
        tabItem("analyse_biv", box(plotOutput("boxplot"), width = 15))
    )
))
  server <- function(input, output, session) {
output$couts_in = renderDataTable(datatable(data1, options= list(scrollX =TRUE)))
output$rev_agri = renderDataTable(datatable(data2, options= list(scrollX =TRUE)))
output$rev_posi = renderDataTable(datatable(data3, options= list(scrollX =TRUE)))
output$cul_qt_recol = renderDataTable(datatable(data4, options= list(scrollX =TRUE)))
output$cult_prix = renderDataTable(datatable(data5, options= list(scrollX =TRUE)))

choix <- reactive({case_when(
  input$select1=="Bases_coûts" ~ list_couts,
  input$select1=="Bases_ménages_rev_pos" ~ list_revenus,
)})
observe({
  updateSelectInput(session, "select2", choices = choix())

})

observeEvent(input$Bouton1, {
  base_donne =NULL
  if (input$select1=="Bases_coûts")
  {
    base_donne <-data1
  }
  else
  {
    base_donne <-data3
  }

  output$Bouton1_out <- renderPrint({summary(base_donne[input$select2])})
  })

output$boxplot <- renderPlot({ boxplot(moyenne_prix ~ etat3_du_produit, data = data5,
                                       main = "Variation des prix par état du produit ",
                                       xlab = "État",
                                       ylab = "Prix")
})




}

shinyApp(ui, server)














