
# Apurement des bases
library(haven)
library(dplyr)
library(esquisse )
library(data.table)
library(tidyverse)
library(readxl)
library(visdat)
library(foreign)


## Préparation des données

### Importation des données

chemin="C:\\Users\\ROSSA\\Desktop\\Ressources_pour_R\\Projet_R_Revenu_agricole_ISEP2_2022-2023\\RevenuAGRICOLE"

RAG_parcelles= read_dta(file = paste0(chemin,"\\s16a_me_SEN_2021.dta"))
RAG_cout_intrants= read_dta(file = paste0(chemin,"\\s16b_me_SEN_2021.dta"))
RAG_cultures= read_dta(file = paste0(chemin,"\\s16c_me_SEN_2021.dta"))
RAG_utilisation_prod= read_dta(file = paste0(chemin,"\\s16d_me_SEN_2021.dta"))


## Manipulation de la deuxième base des donnees _parcelles_

##Structure des données
dim(RAG_parcelles)
names(RAG_parcelles)
glimpse(RAG_parcelles)


## les lignes de début et de fin
head(RAG_parcelles, n=5) 
tail(RAG_parcelles, n=5) 

View(RAG_parcelles)

# Convertion du jeu de donnée en data frame
typeof(RAG_parcelles)
class(RAG_parcelles)
RAG_parcelles <- data.frame(RAG_parcelles)
class(RAG_parcelles)

#description de la base
questionr::describe(RAG_parcelles)


### Choix des variables d'interet

parcelles=RAG_parcelles %>%
  select(interview__key, interview__id, grappe, id_menage, vague,s16aq00, s16aq08,s16aq08_autre ,s16aq09a, s16aq09b)

View(parcelles)



### Renommage des variables variables clés.

new_name = c(colnames(parcelles)[1], colnames(parcelles)[2],colnames(parcelles)[3],colnames(parcelles)[4], colnames(parcelles)[5],"culture_terre","Id_culture","autre_culture_principale", "superficie_parcelle","unite_mesure_parcelle")

isTRUE(length(new_name)==length(colnames(parcelles))) 

colnames(parcelles) = new_name
colnames(parcelles)

### Identification et correction des valeurs manquantes

questionr::describe(parcelles$culture_terre)

## choix des ménages ayant pratiqué
parcelles= subset(parcelles, parcelles$culture_terre!=2)
View(parcelles)

table_sem <- table(parcelles$superficie_parcelle)
print(table_sem)

## suppresion des observation ne sait pas
parcelles= subset(parcelles, parcelles$superficie_parcelle!=9999)



#### Conversion de la superficie en hectare pour les ménages dont la superficie est en m²

parcelles=parcelles %>%
  mutate(superficie_parcelle_ha=ifelse(unite_mesure_parcelle==2,superficie_parcelle/10000,superficie_parcelle))

View(parcelles)

### Selection des variables definitives

parcelles=parcelles %>%
  select(interview__key, interview__id, grappe, id_menage, vague,culture_terre,Id_culture, autre_culture_principale, superficie_parcelle_ha)


### Traitement des modalités des variables autres

table_s <- table(parcelles$autre_culture_principale)

parcelles=parcelles %>%
  mutate(autre_culture_principale=ifelse(autre_culture_principale=="Orange"|autre_culture_principale=="orange", "orange",
                                                   ifelse(autre_culture_principale=="citron"|autre_culture_principale=="Citron"|autre_culture_principale=="citrons", "citron",
                                          ifelse(autre_culture_principale=="cajou"|autre_culture_principale=="acajou"|autre_culture_principale=="Acajou", "acajou",
                                                autre_culture_principale))))

questionr::describe(parcelles$Id_culture)

View(parcelles)


parcelles=parcelles %>%
  mutate(Id_culture=ifelse(autre_culture_principale=="orange",65,
                     ifelse(autre_culture_principale=="citron", 66,
                      ifelse(autre_culture_principale=="acajou", 67,
                        ifelse(autre_culture_principale=="feuille d'oseille", 68,
                          ifelse(autre_culture_principale=="fleur", 69,
                             ifelse(autre_culture_principale=="bissap", 70,
                               ifelse(autre_culture_principale=="gadiangé", 71,
                                  ifelse(autre_culture_principale=="Bèrèv", 72,
                                    ifelse(autre_culture_principale=="bénet", 73,
                                                                                               
                            ifelse(autre_culture_principale=="oranges  citrons  anacardes", 74, Id_culture)))))))))))


## visualisation des valeurs manquantes.

vis_miss(parcelles)


### Exportation de la base apurée des récoltes 

write_dta(parcelles, 'parcelles_apure.dta')
write.csv(parcelles, 'parcelles_apure.csv')


## Manipulation de la deuxième base des donnees _couts des intrants_
## structure des données
dim(RAG_cout_intrants)

names(RAG_cout_intrants)

glimpse(RAG_cout_intrants)

## lignes de début et de fin
head(RAG_cout_intrants, n=5) 
tail(RAG_cout_intrants, n=5) 

View(RAG_cout_intrants)

# Convertion du jeu de donnée en data frame
typeof(RAG_cout_intrants)
class(RAG_cout_intrants)
RAG_cout_intrants <- data.frame(RAG_cout_intrants)
class(RAG_cout_intrants)

#description de la base
questionr::describe(RAG_cout_intrants)

## Selection des variables cles

cout_intrants=RAG_cout_intrants %>%
  select(interview__key, interview__id, grappe, id_menage, vague,s16bq02, s16bq08, s16bq09c)

View(cout_intrants)


### Renommage des variables

new_name = c(colnames(cout_intrants)[1], colnames(cout_intrants)[2],colnames(cout_intrants)[3],
              colnames(cout_intrants)[4], colnames(cout_intrants)[5], "util_intrant",  "achat_intrant","montant_achat_intrant")

isTRUE(length(new_name)==length(colnames(cout_intrants))) 

colnames(cout_intrants) = new_name

colnames(cout_intrants)

## Agregation des couts selon les ménages
cout_intrants=cout_intrants %>% 
            group_by(interview__key)%>% 
            summarize(montant_menage=sum(montant_achat_intrant, na.rm = TRUE))

#description des variables
questionr::describe(cout_intrants)

vis_miss(cout_intrants)

write_dta(cout_intrants, 'cout_intrants_apure.dta')
write.csv(cout_intrants, 'cout_intrants_apure.csv')


## Manipulation de la troisième base de données _Culture_


dim(RAG_cultures) 
names(RAG_cultures)

glimpse(RAG_cultures)


##
head(RAG_cultures, n=5) 
tail(RAG_cultures, n=5) 

View(RAG_cultures)

# Convertion du jeu de donnée en data frame
typeof(RAG_cultures)
class(RAG_cultures)
RAG_cultures <- data.frame(RAG_cultures)
class(RAG_cultures)

#description des variables
questionr::describe(RAG_cultures)

## Selection des variables cles

cultures=RAG_cultures %>%
  select(interview__key, interview__id, grappe, id_menage, vague,s16cq04,s16cq16c,s16cq16d )

View(cultures)

## Renommage des variables selectionnées

new_name = c(colnames(cultures)[1], colnames(cultures)[2],colnames(cultures)[3],
              colnames(cultures)[4], colnames(cultures)[5] ,"Id_culture","qte_recoltee_kg","etat_recolte" )

isTRUE(length(new_name)==length(colnames(cultures))) 
colnames(cultures) = new_name

colnames(cultures)

#description des variables
questionr::describe(cultures)

### Visualisation des valeurs manquantes

vis_miss(cultures) 

### Supression des valeurs manquantes de la variable _Id_culture_


cultures = subset(cultures,!is.na(cultures$Id_culture))

vis_miss(cultures)

### Exportation de la base apurée des récoltes 

write_dta(cultures, 'cultures_apure.dta')
write.csv(cultures, 'cultures_apure.csv')

## Manipulation de la quatrièma base de données et regroupement de toutes les bases 


names(RAG_utilisation_prod)

glimpse(RAG_utilisation_prod)

head(RAG_utilisation_prod, n=5) 
tail(RAG_utilisation_prod, n=5) 

View(RAG_utilisation_prod)

# Convertion du jeu de donnée en data frame
typeof(RAG_utilisation_prod)
class(RAG_utilisation_prod)
RAG_utilisation_prod <- data.frame(RAG_utilisation_prod)
class(RAG_utilisation_prod)

#description des données
questionr::describe(RAG_utilisation_prod)


## Sélectionner des variables

utilisation_prod=RAG_utilisation_prod %>%
  select(interview__key, interview__id,grappe,id_menage,vague,s16dq01,s16dq02a, s16dq02b, s16dq02b_autre, s16dq02c, s16dq03a, s16dq03b, s16dq03b_autre, s16dq03c, s16dq04, s16dq05a, s16dq05b, s16dq05b_autre,s16dq05c, s16dq05d, s16dq06, s16dq09, s16dq10, s16dq12, s16dq13a, s16dq13b, s16dq13b_autre, s16dq13c,  s16dq15, s16dq17a, s16dq17b, s16dq17b_autre, s16dq17c)

new_name = c(colnames(utilisation_prod)[1], colnames(utilisation_prod)[2],colnames(utilisation_prod)[3],
              colnames(utilisation_prod)[4], colnames(utilisation_prod)[5], 'Id_culture','qte_consomme','unite1_mesure', 'autre_unite', 'etat_du_produit', 'qte_offerte', 'unite2_mesure', 'autre_unite2', 'etat2_du_produit', 'prod_vendue','qte_vendue', 'unite3_mesure', 'autre_unite3',"estimation_qte_totale" ,'etat3_du_produit', 'montant_vente', 'vente_residue_prod', 'revenu_vente_residue', 'prod_en_stock', 'qte_en_stock','unite4_mesure','autre_unite4', 'etat4_du_produit', 'prod_en_stock_a_vendre', 'qte_en_stock_a_vendre', 'unite5_mesure', 'autre_unite5', 'etat5_du_produit')

isTRUE(length(new_name)==length(colnames(utilisation_prod))) 

colnames(utilisation_prod) = new_name

colnames(utilisation_prod)

View(utilisation_prod)

# Visualisation des valeurs manquantes

vis_miss(utilisation_prod)

## remplacer certaines quantité et montant par 0 en fonction de la réponse du répondant
utilisation_prod=utilisation_prod %>% 
              mutate(qte_vendue = ifelse(prod_vendue==2, 0,qte_vendue ),
                     montant_vente=ifelse(prod_vendue==2, 0,montant_vente),
                     revenu_vente_residue=ifelse(vente_residue_prod==2, 0, revenu_vente_residue),
                     prod_en_stock_a_vendre=ifelse(prod_en_stock==2, 2, prod_en_stock_a_vendre),
                     qte_en_stock=ifelse(prod_en_stock==2, 0, qte_en_stock),
                     qte_en_stock_a_vendre=ifelse(prod_en_stock_a_vendre==2, 0,  qte_en_stock_a_vendre))

View(utilisation_prod)

vis_miss(utilisation_prod)


### Suppression des valeurs manquantes de la variable _montant_vente_

utilisation_prod= subset(utilisation_prod,
               !is.na(utilisation_prod$montant_vente))

vis_miss(utilisation_prod)

## exportation des données
write_dta(utilisation_prod, 'utilisation_prod_apure.dta')
write.csv(utilisation_prod, 'utilisation_prod_apure.csv')


base = merge(parcelles, cultures , by=c("interview__key","Id_culture"), all.x = TRUE)
base=distinct(base)

base2 = merge(base, utilisation_prod, by =c("interview__key","Id_culture"),all.x= TRUE)
base2 = select(base2,-interview__id.y,-grappe.y,-id_menage.y,-vague.y,-interview__id,-grappe,-id_menage,-vague)

base2 = base2 %>% 
mutate(qte_recoltee_kg = ifelse(is.na(qte_recoltee_kg),estimation_qte_totale,qte_recoltee_kg ))

## supprimer les lignes où nous avons des NA dans les variables qui suivent
vars = c("qte_recoltee_kg", "qte_consomme", "qte_offerte", "estimation_qte_totale", "qte_en_stock")
for (row in 1:nrow(base2)) {
  if (all(is.na(base2[row, vars]))){
    base2 = slice(base2, -row)
  }
}


### Conversion de la quantité consommée en kg

base2=base2 %>% 
      mutate(qte_consomme = ifelse(unite1_mesure==1,qte_consomme,ifelse(unite1_mesure==2,qte_consomme*25,ifelse(unite1_mesure==3,qte_consomme*50,ifelse(unite1_mesure==4,qte_consomme*100,ifelse(unite1_mesure==5,qte_consomme*0.5,ifelse(unite1_mesure==6,qte_consomme,ifelse(unite1_mesure==7,qte_consomme*2,ifelse(unite1_mesure==8,qte_consomme*25,qte_consomme)))))))))


### Conversion de la quantité offerte en kg


base2=base2 %>% 
      mutate(qte_offerte = ifelse(unite2_mesure==1,qte_offerte,ifelse(unite2_mesure==2,qte_offerte*25,ifelse(unite2_mesure==3,qte_offerte*50,ifelse(unite2_mesure==4,qte_offerte*100,ifelse(unite2_mesure==5,qte_offerte*0.5,ifelse(unite2_mesure==6,qte_offerte,ifelse(unite2_mesure==7,qte_offerte*2,ifelse(unite2_mesure==8,qte_offerte*25,qte_offerte)))))))))


### Conversion de la quantité vendue en kg


base2=base2 %>% 
      mutate(qte_vendue = ifelse(unite3_mesure==1,qte_vendue,ifelse(unite3_mesure==2,qte_vendue*25,ifelse(unite3_mesure==3,qte_vendue*50,ifelse(unite3_mesure==4,qte_vendue*100,ifelse(unite3_mesure==5,qte_vendue*0.5,ifelse(unite3_mesure==6,qte_vendue,ifelse(unite3_mesure==7,qte_vendue*2,ifelse(unite3_mesure==8,qte_vendue*25,qte_vendue)))))))))


### Conversion de la quantité stockée en kg


base2=base2 %>% 
      mutate(qte_en_stock = ifelse(unite4_mesure==1,qte_en_stock,ifelse(unite4_mesure==2,qte_en_stock*25,ifelse(unite4_mesure==3,qte_en_stock*50,ifelse(unite4_mesure==4,qte_en_stock*100,ifelse(unite4_mesure==5,qte_en_stock*0.5,ifelse(unite4_mesure==6,qte_en_stock,ifelse(unite4_mesure==7,qte_en_stock*2,ifelse(unite4_mesure==8,qte_en_stock*25,qte_en_stock)))))))))


### Conversion de la quantité stockée à vendre en kg


base2=base2 %>% 
      mutate(qte_en_stock_a_vendre = ifelse(unite5_mesure==1,qte_en_stock_a_vendre,ifelse(unite5_mesure==2,qte_en_stock_a_vendre*25,ifelse(unite5_mesure==3,qte_en_stock_a_vendre*50,ifelse(unite5_mesure==4,qte_en_stock_a_vendre*100,ifelse(unite5_mesure==5,qte_en_stock_a_vendre*0.5,ifelse(unite5_mesure==6,qte_en_stock_a_vendre,ifelse(unite5_mesure==7,qte_en_stock_a_vendre*2,ifelse(unite5_mesure==8,qte_en_stock_a_vendre*25,qte_en_stock_a_vendre)))))))))


base2=base2 %>%
  mutate(qte_recoltee_kg = ifelse(is.na(qte_recoltee_kg),ifelse(is.na(qte_consomme), 0, qte_consomme) + ifelse(is.na(qte_en_stock), 0, qte_en_stock) + ifelse(is.na(qte_vendue), 0, qte_vendue) + ifelse(is.na(qte_offerte), 0, qte_offerte),qte_recoltee_kg))




### Calcul des prix unitaires

base2$prix_unitaire = base2$montant_vente/base2$qte_vendue)
prix = subset(base2, select=c(Id_culture, prix_unitaire, etat3_du_produit))

# Extraction des prix sans NA et sans doublons
prix <- prix[complete.cases(prix$prix_unitaire) , ]
prix = distinct(prix)



### Moyenne des prix suivant l'état de la culture vendue et son identifiant

prix <- prix %>%
  group_by(etat3_du_produit, Id_culture) %>%
  summarise(moyenne_prix = mean(prix_unitaire))

### Extraction du prix suivant les cultures sans leur état

culture_prix = prix %>%
  group_by(Id_culture) %>%
  summarise(moyenne_prix = mean(moyenne_prix))
  
### Extraction des revenus issus de la vente des résidus des cultures suivant les ménages


revenus_residus = subset( base2, select=c(interview__key,revenu_vente_residue))

revenus_residus <- revenus_residus %>%
  group_by(interview__key) %>%
  summarise(somme_revenus_residus = sum(revenu_vente_residue))


cultures <- cultures %>%
  rename(etat = etat_recolte)

prix <- prix %>%
  rename(etat=etat3_du_produit)



### Valorisation de la récolte pour chaque culture pratiquée par le ménage

recolte_val= merge(cultures, prix, by= c("Id_culture"), all.x = TRUE)
recolte_val$valeur = (recolte_val$qte_recoltee_kg)*(recolte_val$moyenne_prix)


### Valorisation totale par ménage

recolte_val <- recolte_val %>%
  group_by(interview__key) %>%
  summarise(somme_valeur = sum(valeur))


### Création des bases pour calculer le revenu final

revenu_agri= merge(recolte_val,cout_intrants,by="interview__key",all.x=TRUE)
revenu_to = merge(revenu_agri,revenus_residus, by="interview__key", all.x = TRUE)


### Calcul du revenu final


revenu_to = revenu_to %>%
 mutate(revenu_total_calcul= ifelse(is.na(somme_valeur),0,somme_valeur) - ifelse(is.na(montant_menage),0,montant_menage) + ifelse(is.na(somme_revenus_residus),0,somme_revenus_residus))

### Sélection

selection= subset(revenu_to,
               !is.na(revenu_to$somme_valeur))

View(selection)


head(selection, 5)


### Exportation de la base avec les revenus agricoles

write_dta(cout_intrants, 'selection.dta')

write.csv(cout_intrants, 'selection.csv')

## selection des ménages ayant un revenu positif
menages_revenu_positf=subset(selection, revenu_total_calcul>0)


View(menages_revenu_positf)


# Analyse descriptive des variables d'interet

## Analyse descriptive univariée

##### Couts d'intrants

summary(cout_intrants$montant_menage)

hist(cout_intrants$montant_menage, freq = TRUE ,
     main = "Couts des intrants agricoles", 
     xlab = "Montant")

##### Revenu obtenu par la vente des residus de production


summary(selection$somme_revenus_residus)


##### Revenu total obtenu

mean(menages_revenu_positf$revenu_total_calcul)
median(menages_revenu_positf$revenu_total_calcul)

## Analyse descriptive bivariée

boxplot(moyenne_prix ~ etat, data = prix)


